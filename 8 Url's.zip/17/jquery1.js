$(function(){
  $('#header_nav').data('size','big');
});

$(window).on('resize',function(){window.location=window.location;});
var windowWidth = $(window).width();
if(windowWidth > 980) {
$(window).scroll(function(){
	
  if($(document).scrollTop() > 250)
{
    if($('#header_nav').data('size') == 'big')
    {
        $('#header_nav').data('size','small');
        $('#header_nav').stop().animate({
            height:'90px'
        },600);
        $('#log').attr('src','logo-mobile.png');
        $('#content').hide();
    }
}
else
  {
    if($('#header_nav').data('size') == 'small')
      {
        $('#header_nav').data('size','big');
        $('#header_nav').stop().animate({
            height:'130px'
        },600);
        $('#log').attr('src','els-logo.png');
        $('#content').show();
      }  
  }
});
}



