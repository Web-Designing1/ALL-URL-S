function validateForm() {
	var fname=document.myForm.fname.value;
	var lname=document.myForm.lname.value;
	var gender=document.myForm.gender.value;
	var email=document.myForm.email.value;
	var phone=document.myForm.number.value;
	var country=document.myForm.country.value;
	var year=document.myForm.year.value;
	var help=document.myForm.help.value;
	var study=document.myForm.study.value;
	var check=document.myForm.check.value;
	if(fname && lname && gender && email && phone && country && year && help && study && check) {
		return true;
		}
	else {
		fnameValidate();
		lnameValidate();
		genderValidate();
		emailValidate();
		phoneValidate();
		countryValidate();
		yearValidate();
		helpValidate();
		studyValidate();
		validateFormCheck();
		errorMessageDisplay();
		}
		return false;
			}	
			
function errorMessageDisplay() {
	var list="";
	if(fnameValidate() && lnameValidate() && genderValidate() && emailValidate() && phoneValidate() && countryValidate() && yearValidate() && helpValidate() && studyValidate() && validateFormCheck()) {
		document.getElementById("error_message").innerHTML="";
		document.getElementById("error_message").className="error_message1";
		return true;
		}
	else {
		document.getElementById("error_message").className="error_message";
		if(!fnameValidate()) {
			list=list + "<li>" + document.getElementById("first").innerHTML + "</li>";
			}
		if(!lnameValidate()) {
			list=list + "<li>" + document.getElementById("last").innerHTML + "</li>";
			}
		if(!genderValidate()) {
			list=list + "<li>" + document.getElementById("gendero").innerHTML + "</li>";
			}
		if(!emailValidate()) {
			list=list + "<li>" + document.getElementById("Email").innerHTML + "</li>";
			}
		if(!phoneValidate()) {
			list=list + "<li>" + document.getElementById("Phone").innerHTML + "</li>";
			}
		if(!countryValidate()) {
			list=list + "<li>" + document.getElementById("Country").innerHTML + "</li>";
			}
		if(!yearValidate()) {
			list=list + "<li>" + document.getElementById("Year").innerHTML + "</li>";
			}
		if(!helpValidate()) {
			list=list + "<li>" + document.getElementById("Help").innerHTML + "</li>";
			}
		if(!studyValidate()) {
			list=list + "<li>" + document.getElementById("Study").innerHTML + "</li>";
			}
		if(!validateFormCheck()) {
			list=list + "<li>" + document.getElementById("Check").innerHTML + "</li>";
			}
		document.getElementById("error_message").innerHTML=list;
		return false;
		}
	}
				
	/* for First Name */
				
function fnameValidate() {
	var text=/^\s+$/;
	var x=document.myForm.fname.value;
	if(x=="" || text.test(x)){
		document.getElementById("first").innerHTML="الحقل الاسم الأول مطلوب.";
		document.getElementById("first").className="property";
		document.myForm.fname.className="wrong";
		return false;
	}
	else{
		document.getElementById("first").innerHTML="";
		document.myForm.fname.className="correct";
		return true;
	}
}

	/* for Last Name */
	
function lnameValidate() {
	var text=/^\s+$/;
	var x=document.myForm.lname.value;
	if(x=="" || text.test(x)){
		document.getElementById("last").innerHTML="الحقل الاسم الأخير/ اسم العائلة مطلوب.";
		document.getElementById("last").className="property";
		document.myForm.lname.className="wrong";
		return false;
	}
	else{
		document.getElementById("last").innerHTML="";
		document.myForm.lname.className="correct";
		return true;
	}
	}

	/* for Gender */

function genderValidate() {
	if(document.myForm.gender.value==""){
		document.getElementById("gendero").innerHTML="الحقل الجنس مطلوب.";
		document.getElementById("gendero").className="property";
		document.getElementById("genderm").style.color="#a94442";
		document.getElementById("genderf").style.color="#a94442";
		
		return false;
		}
	else{
		document.getElementById("gendero").innerHTML="";
		document.getElementById("genderm").style.color="#007722";
		document.getElementById("genderf").style.color="#007722";
		return true;
		}
	}
			
function validateFormGender() {
	var male=document.getElementById("gender_male");
	var female=document.getElementById("gender_female");
	if(male.checked==true || female.checked==true){
		document.getElementById("gendero").innerHTML="";
		document.getElementById("genderm").style.color="#007722";
		document.getElementById("genderf").style.color="#007722";
		return true;
		}
	}
	
	/* for Email */
	
function emailValidate() {
	var text=/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	var x=document.myForm.email.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Email").innerHTML="الحقل البريد الإلكتروني مطلوب.";
		document.getElementById("Email").className="property";
		document.myForm.email.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.email.className="correct";
		document.getElementById("Email").innerHTML="";
		return true;
		}
	}
	
function validateFormEmail() {
	var y=document.myForm.email.value;
	if(y.match(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)) {
		document.myForm.email.className="correct";
		document.getElementById("Email").innerHTML="";
		return true;
	}
	else {
		document.myForm.email.className="wrong";
		document.getElementById("Email").innerHTML="يحتوي حقل البريد الإلكتروني على عنوان بريد إلكتروني غير صالح.";
		document.getElementById("Email").className="property";
		return false;
	}
}

	/* for Phone number */
	
function phoneValidate() {
	var text=/^(7|8|9)\d{9}$/;
	var x=document.myForm.number.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Phone").innerHTML="الحقل رقم الهاتف/ رقم الجوال مطلوب.";
		document.getElementById("Phone").className="property";
		document.myForm.number.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.number.className="correct";
		document.getElementById("Phone").innerHTML="";
		return true;
		}
	}
	
function validateFormNumber() {
	var y=document.myForm.number.value;
	if(y.match(/^(7|8|9)\d{9}$/)) {
		document.myForm.number.className="correct";
		document.getElementById("Phone").innerHTML="";
		return true;
	}
	else {
		document.myForm.number.className="wrong";
		document.getElementById("Phone").innerHTML="قيمة الحقل رقم الهاتف/ رقم الجوال غير صالحة.";
		document.getElementById("Phone").className="property";
		return false;
	}
}

	/* for Country */
	
function countryValidate() {
	if(document.myForm.country.value==""){
		document.getElementById("Country").innerHTML="الحقل بلد الإقامة مطلوب.";
		document.getElementById("Country").className="property";
		document.myForm.country.className="valid_sel_wrong";
		
		return false;
		}
	else{
		document.getElementById("Country").innerHTML="";
		document.myForm.country.className="valid_sel_correct";
		return true;
		}
	}

	/* for Year of born */
	
function yearValidate() {
	var text=/\d{4}$/;
	var x=document.myForm.year.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Year").innerHTML="الحقل عام الميلاد مطلوب.";
		document.getElementById("Year").className="property";
		document.myForm.year.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.year.className="correct";
		document.getElementById("Year").innerHTML="";
		return true;
		}
	}
	
function validateFormYear() {
	var y=document.myForm.year.value;
	if(y.match(/\d{4}$/) && y>=1900 && y<=2016) {
		document.myForm.year.className="correct";
		document.getElementById("Year").innerHTML="";
		return true;
	}
	else {
		document.myForm.year.className="wrong";
		document.getElementById("Year").innerHTML="الرقم في عام الميلاد يجب أن يكون على الأقل 1900 ولا يزيد عن 2016.";
		document.getElementById("Year").className="property";
		return false;
	}
}

	/* for Help */
	
function helpValidate() {
	if(document.myForm.help.value==""){
		document.getElementById("Help").innerHTML="الحقل ما الأمر الذي ترغب في الحصول على مساعدة بشأنه؟ مطلوب.";
		document.getElementById("Help").className="property";
		document.myForm.help.className="valid_sel_wrong";
		
		return false;
		}
	else{
		document.getElementById("Help").innerHTML="";
		document.myForm.help.className="valid_sel_correct";
		return true;
		}
	}

	/* for Study */

function studyValidate() {
	if(document.myForm.study.value==""){
		document.getElementById("Study").innerHTML="الحقل في أي مكان ترغب في تلقي الدراسة؟ مطلوب.";
		document.getElementById("Study").className="property";
		document.myForm.study.className="valid_sel_wrong";
		return false;
		}
	else {
		document.getElementById("Study").innerHTML="";
		document.myForm.study.className="valid_sel_correct";
		return true;
		}
	}

	/* for Checkbox */
	
function validateFormCheck() {
	var value=document.getElementById("check");
	if(value.checked==true){
		document.getElementById("Check").innerHTML="";
		return true;
		}
	else {
		document.getElementById("Check").innerHTML="الحقل شروط وأحكام مطلوب.";
		document.getElementById("Check").className="property";
		return false;
		}
	}

