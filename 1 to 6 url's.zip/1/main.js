﻿jQuery(function ($) {
    $(document).on('click', '.WFFM-form', function () {
        var ch = $(this).find(':submit');
        if ($(this).find(':submit').prop('disabled')) {
            if ($('.has-error').length <= 1) {
                $(this).find(':submit').removeAttr('disabled');
            }
        }
    });
    $('.WFFM-form').submit(function () {
        $(this).find(':submit').attr('disabled', 'disabled');
        var validCheck = $('.input-validation-error').length;
        if ($(this).find('.input-validation-error').length != 0) {
            $(this).find(':submit').removeAttr('disabled');
        }
        else {
            $("body").append("<div id='overlay'><div class='errorContainer'><img src='/images/spinner.gif' /></div><div><div></div>");
            //We are going to submit the form, so lets show the overlay!
            document.getElementById("overlay").style.display = "block";
            //Setting millisecond fo 10000 to simulate a file upload...
            //setTimeout(function () {
            //    document.getElementsByClassName("WFFM-form").submit();
            //}, 10000);
        }
    });
    var mobileButton = $('.navigation-button');
    var isMobileLayout = mobileButton.is(':visible');

    // ELS Module
    var ELS = (function (window, undefined) {

        // Equal Height
        // Summary:
        // Set all elements with the class 'equal-height' to the same height
        // of the tallest element
        function browserResize() {
            $(window).on('browserResize', function (e) {
                //resize just happened, pixels changed
                var mobileButtonCheck = jQuery('.navigation-button');
                var isMobileLayoutCheck = mobileButtonCheck.is(':visible');

                if (isMobileLayoutCheck) {
                    moveUtilityNav();
                    jQuery('.equal-height').css('height', 'auto');
                }
                else {
                    var utilityNav = $('.header-navigation-utility');
                    var utilitySelector = $('.header-navigation-utility-selector');
                    var seperator = $('.header-navigation-utility-separater');
                    var navList = $('header-navigation-list');
                    var searchBar = $('header-navigation-search');

                    var displayTest = utilitySelector.attr('style');
                    if (typeof displayTest !== typeof undefined && displayTest !== false) {
                        if (displayTest == "display: block;") {

                            utilitySelector.css("display", "");
                            navList.css("display", "inline-block");
                            utilitySelector.attr("style", "");
                            navList.attr("style", "");
                        }
                        if (displayTest == "display: none;") {

                            utilitySelector.removeAttr('style');
                            utilityNav.removeAttr('style');
                            navList.removeAttr('style');
                            searchBar.removeAttr('style');
                        }

                    }

                    /* JP 7/25/17 -> Commented these lines out since it was 
                    causing the GlobalSearchBox to move during BrowserResize */

                    // seperator.before(utilitySelector);
                    // utilityNav.insertAfter(mobileButtonCheck);

                    //utilitySelector.css({ display: 'inline-block' });
                }
            });



        }

        // Mobile navigation functionality
        // Summary:
        // Clicking the mobile nav button will reveal the menu in a slide down animation
        // and make the hamburger icon animate.
        function mobileNavigation() {

            /* JP 7/10/2017 -> Added 'navbar-fixed-bottom' to Utility List Class */

            var header = $('.header');

            /* JP 7/26/17 -> Move Utility List out of Nav container for Tablet Widths */

            var utility_list = $('.header-navigation-utility');

            var utility_bottom = $('.header-navigation-utility-list');

            /* JP 7/31/17 -> Change bottom Nav Items to shorter names */

            //  var utility_childs = document.getElementById('utility-list-menu').childNodes;

            /* JP 7/25/17 
            Hide the Top Search Div during Mobile views
            */
            var TopSearch = $('.header-navigation-top-search');

            // JP 7/25/17 -> Added Window Scroll function for Mobile Widths
            // collapse the navbar on scroll                        

            // TopSearch.css("display", "none");




            // JP 7/31/17 Added Arrays to change bottom mobile button text


            //var menu_items = [];

            //// Store innertext of Menu Items into array
            //$('#utility-list-menu li a').each(function (i) {
            //    menu_items.push($(this).text());

            //    // $(this).text(menu_items_mobile[i]); 
            //});


            //var menu_items_mobile = [
            //    "Questions",
            //    "Contact",
            //    "Apply"];



            $(window).bind("resize", function () {
                // console.log($(this).width())

                /*
                if ($(this).width() > 992) {
                    TopSearch.css("display","block");
                }
                else {
                    TopSearch.css("display","none");
                }
                */


                var $utilitymenu = $('#utility-list-menu li a');

                if ($(this).width() > 414) {


                    // When the browser is not in mobile, place the original menu items back
                    for (var i = 0; i < $utilitymenu.length; i++) {
                        $utilitymenu.each(function (i) {
                            $(this).text($(this).data("long-title"));
                        });
                    }

                }

                /* JP 7/26/17 -> Added JS to move Utility Nav to bottom of header */

                if (($(this).width() > 414)) {
                    // $("#source").appendTo("#destination");
                    utility_list.appendTo(".header");
                    $('.header-navigation-myels-container').appendTo('.header-language-container');


                } else {
                    utility_list.appendTo(".header-navigation");
                    $('.header-navigation-myels-container').appendTo('.header-navigation-list');
                }


                /* Make the Utility List Stay at the Bottom */

                if ($(this).width() > 948) {

                    //utility_bottom.removeClass('navbar-fixed-bottom');
                    //header.addClass('navbar-fixed-top');

                } else if (($(this).width() > 414) && ($(this).width() < 948)) {
                    // utility_bottom.addClass('navbar-fixed-bottom');
                    // header.removeClass('navbar-fixed-top');
                    //utility_bottom.removeClass('navbar-fixed-bottom');
                    // utility_list.removeClass('utilitynav-hidden');
                } else {
                    //utility_bottom.addClass('navbar-fixed-bottom');

                    // Added loop to change innertext of bottom buttons for mobile
                    for (var i = 0; i < $utilitymenu.length; i++) {
                        $utilitymenu.each(function (i) {
                            //$(this).text(menu_items_mobile[i]);
                            $(this).text($(this).data("short-title"));
                        });
                    }


                    /* 
                     $(".header-navigation-utility-list li a:nth-of-type(1)").text("Questions");
                     $(".header-navigation-utility-list li a:nth-of-type(2)").text("Contact");
                     $(".header-navigation-utility-list li a:nth-of-type(3)").text("Apply");
                     */

                    /*
                    for (var i = 0; i < utility_childs.length; i++) {
                        if (utility_childs[i].nodeType != 1) {
                            continue;
                        }
                        utility_childs[i].textContent = "short";
                    }
                    */


                }

            }).trigger('resize');

            /*
            if (window.matchMedia("(max-width: 992px)").matches) {
                // The screen is less than or equal to 992px
                utility_bottom.addClass('navbar-fixed-bottom');
            }
            else {
                // The screen is greater than 992px
                utility_bottom.removeClass('navbar-fixed-bottom');
            }
            */

            // var mq = window.matchMedia("(max-width: 992px)");

            /*
            if (mq.matches) {
                utility_bottom.removeClass('navbar-fixed-bottom');
            } else {
                utility_bottom.addClass('navbar-fixed-bottom');
            }
            */

            //$(document).ready(function () {
            //      $('body').on('click', '.infowindow_link', function() {
            //       // window.location.href = this.href;
            //    });
            //});

            var icon = $('.navigation-icon');
            var button = $('.navigation-button');
            var navigation = $('.header-navigation-list, .header-navigation-search, .header-navigation-utility, .header-navigation-utility-selector');

            // var button_active = $('.navigation-icon--active');

            // utility_bottom.addClass('navbar-fixed-bottom');

            button.on('click', function (e) {
             //   console.debug("click stopped");
                e.preventDefault();

                icon.toggleClass('navigation-icon--active');

                // JP 7/26/17 Remove Utility List When Mobile Menu is Opened
                if ($(window).width() < 414) {
                    $('.header-navigation-utility-list').toggleClass('utilitynav-hidden');
                }

                // navigation.slideToggle(500, function () {
                // // Remove previously applied classes
                // $('.header-navigation .parent-hidden').removeClass('parent-hidden hidden');
                // $('.header-navigation .parent-active').removeClass('parent-active');
                // $('.header-navigation .parent-back').removeClass('parent-back');
                // });
                $('.header-navigation-menu-container').toggleClass('mobile-nav-visible', function () {
                    // Remove previously applied classes
                    $('.header-navigation .parent-hidden').removeClass('parent-hidden hidden');
                    $('.header-navigation .parent-active').removeClass('parent-active');
                    $('.header-navigation .parent-back').removeClass('parent-back');

                    // JP 7/25/17 Add Language Selector and GlobalSearch
                    // Add Search and Language Selector TextBoxes
                    $('.header-navigation-top-search').toggleClass('top-search-hidden');

                });

                return false;
            });

            /*
            button_active.on('click', function (e) {
                e.preventDefault();                

                // JP 7/26/17 Remove Utility List When Mobile Menu is Opened
                $('.header-navigation-utility-list').removeClass('utilitynav-hidden');                

                return false;
            });
            */


        }
        //--/ Mobile navigation functionality


        // Move Utility Nav
        // Summary:
        // For mobile, move the utility nav below the main navigation and search.
        // We also need to move the language selector below the utility navigation menu.
        function moveUtilityNav() {

            var utilityNav = $('.header-navigation-utility');
            var utilitySelector = $('.header-navigation-utility-selector');
            var navigation = $('.header-navigation-menu-container');

            var mobileButtonCheck = jQuery('.navigation-button');
            var isMobileLayoutCheck = mobileButtonCheck.is(':visible');


            //utilityNav.appendTo(".header .container-fluid");

            if (isMobileLayoutCheck) {

                // utilitySelector.appendTo(navigation);

            }
            else {

                //utilitySelector.appendTo(utilityNav);
                //utilityNav.insertAfter(mobileButtonCheck);
            }
        }
        //--/ Move Utility Nav

        // Generate Sub Nav Overview Links
        // Summary:
        // For the sub nav, we need to grab the link for each parent menu item and make it the first
        // menu item in the sub menu and add the text "Overview" to the end of it. The parent level menu
        // items will never take you to the landing pages. 
        function generateSubNavLinks() {
            var parentItem = $('.header-navigation li.parent');

            // Loop through each parent, clone the link, prepend it to the submenu
            $(parentItem).each(function () {
                var itemClone = $(this).children('a').clone();
                itemClone.prependTo($(this).children('ul')).wrap('<li></li>').html(itemClone.html());
            });
        }
        //--/ Generate Sub Nav Overview Links

        // Parent menu item functionality
        // Summary:
        // When clicking a parent menu item with children, we don't want to go to that link,
        // we want to reveal the sub menu.
        function parentMenuItem() {
            var parentItem = $('.header-navigation li.parent > a');
            var elementsToHide = $('.header-navigation-search, .header-navigation-utility, .header-navigation-utility-selector, .language-selector');

            parentItem.on('click', function (e) {
                //console.debug("nav parent click");
                e.preventDefault();
                e.stopPropagation();
                var parent = $(this).closest('.parent');

                if (isMobileLayout) {
                    if (parent.hasClass('parent-back')) {
                        parent.removeClass('parent-back').children('ul').removeClass('parent-active');
                        parent.siblings('li').removeClass('parent-hidden hidden');
                        elementsToHide.removeClass('parent-hidden hidden');
                    }
                    else {
                        parent.addClass('parent-back').children('ul').addClass('parent-active');
                        parent.siblings('li').addClass('parent-hidden hidden');
                        elementsToHide.addClass('parent-hidden hidden');
                    }
                }
                else {
                    if (parent.children('ul').hasClass('parent-active')) {
                        parent.children('ul').removeClass('parent-active');
                        parent.children('a').removeClass('active');
                    }
                    else {
                        $('ul.parent-active').removeClass('parent-active');
                        $('.parent a.active').removeClass('active')
                        parent.children('a').addClass('active');
                        parent.children('ul').addClass('parent-active');
                    }

                    // Calculate position of subnav based on parent
                    var $el = parent,
                    elc = $el.width() / 2,
                    $subnav = $el.children('ul');
                    subc = $subnav.width() / 2;

                    $subnav.css({ left: -(subc - elc) + 'px' });
                    //--/Calculate position of subnav based on parent
                }
            });

            $('.parent').on('click', function (e) {
                event.stopPropagation();
               // console.debug(" - parent click");
            });

            $(window).on('click', function (e) {
               // console.debug(" - window click " + e.target.id);
              //  console.debug(e);
                $('.header-navigation .parent a').removeClass('active');
                $('.header-navigation .parent-hidden').removeClass('parent-hidden hidden');
                $('.header-navigation .parent-active').removeClass('parent-active');
                $('.header-navigation .parent-back').removeClass('parent-back');

                if (e.target.id != 'language-toggle') {
                    if (e.target.className == "fa fa-sort-desc")
                    {
					///do nothing
                    }
                    else
                    {
                        $("#language-selector").addClass("hide");
                    }
                }
            });
        }
        //--/ Parent menu item functionality


        // Initialize Hero
        // Summary:
        // Initialize the hero slider functionality
        function hero() {
            $('.hero-image-list').on('init', function () {
                $('.hero-image-list').css("visibility", "visible");
            });
            $('.hero-image-list').slick({
                autoplay: true,
                autoplaySpeed: 5000,
                fade: true,
                arrows: false

            });
        }
        //--/ Initialize Hero


        // Initialize Student Quote
        // Summary:
        // Initialize the student quote slider functionality
        function studentQuote() {

            $('.student-quote-micrositeSection .student-quote-text').slick({
                autoplay: true,
                fade: true,
                arrows: true,
                dots: true,
                infinite: false
            });

            if ($('.student-quote-micrositeSection').length == 0) {
                $('.student-quote-text').slick({
                    autoplay: false,
                    fade: true,
                    arrows: true,
                    dots: true,
                    infinite: false
                });
            }

            $('.student-image-quote').slick({
                autoplay: false,
                fade: true,
                arrows: true,
                dots: true,
                infinite: false

            });

            $('.student-quote-micrositeSection .student-quote-text-isr').slick({
                autoplay: true,
                fade: true,
                arrows: true,
                dots: true,
                infinite: false
            });

            if ($('.student-quote-micrositeSection').length == 0) {
                $('.student-quote-text-isr').slick({
                    autoplay: false,
                    fade: true,
                    arrows: true,
                    dots: true,
                    infinite: false
                });
            }

            $('.student-image-quote-isr').slick({
                autoplay: false,
                fade: true,
                arrows: true,
                dots: true,
                infinite: false

            });
        }
        //--/ Initialize Student Quote

        // Footer navigation functionality
        // Summary:
        // When clicking a parent menu item in the footer, we want
        // to reveal the sub menu
        function footerNavigation() {
            var footerNavigation = $('.footer-navigation-list > li > a');
            footerNavigation.on('click', function (e) {
                e.preventDefault();
                $(this).toggleClass('active');
                $(this).siblings('ul').slideToggle();
            });
        }
        //--/Footer navigation functionality

        // goal tracking functionality
        // Summary:
        // When clicking goalClick class, we register a goal with Sitecore
        function goalTracking() {
            var goalClick = $('.goalClick');
            goalClick.on('click', function (e) {
                //e.preventDefault();
                var value = $(goalClick).data("goal");
                //alert(value);
                var url = "/api/Sitecore/ELS/TriggerPageEvents";

                $.post(url,
                    { goal: value },
                    function (data) {
                        //do nothing, no client interaction needed
                    }
                );
            });
        }
        //--/goal tracking functionality

        // Utility Nav Selector functionality
        // Summary:
        // When clicking or tapping the language selector in the utility nav,
        // we need to reveal the sub menu
        function utilityNavSelector() {
            var utilitySelector = $('.header-navigation-utility-selector');
            var utilitySelectorList = $('.header-navigation-utility-selector-list');
            var utilitySelectorSearch = $('.header-navigation-utility-selector-list-search');
            var utilitySelectorListItem = $('.header-navigation-utility-selector-list-item');

            utilitySelector.on('click', function (e) {
               // console.debug("util selector stop click");
                // e.stopPropagation();
                // e.preventDefault();

                utilitySelectorList.slideToggle();
            });

            utilitySelectorSearch.add(utilitySelectorListItem).on('click', function (e) {
                e.stopPropagation();
            });

            $(window).on('click', function (e) {
                utilitySelectorList.slideUp();
            });
        }
        //--/ Utility nav selector


        // Style Dropdown
        // Summary:
        // Style dropdowns with a custom style using jQuery UI selectmenu
        function styleDropdown() {
            $('.select-menu').selectmenu();
            $('#centers-selector-country').selectmenu('menuWidget').addClass('els-options-list');
            $('#centers-selector-location').selectmenu('menuWidget').addClass('els-options-list');
            $('.search-center-search-selectmenu').selectmenu('widget').addClass('search-center-search-selectmenu');
            $('.search-center-search-selectmenu').selectmenu('menuWidget').addClass('els-options-list');
            $('.destination-list-sort-select .select-menu').selectmenu('widget').addClass('destination-list-sort-selectmenu');
            $('.destination-list-sort-select .select-menu').selectmenu('menuWidget').addClass('els-options-list');
            $('.contact-counselor-country-selectmenu').selectmenu('menuWidget').addClass('els-options-list');
            $('.contact-counselor-country-selectmenu').selectmenu('widget').addClass('contact-counselor-selectmenu');
            $('.contact-counselor-location-selectmenu').selectmenu('widget').addClass('contact-counselor-selectmenu');
            $('.contact-counselor-city-selectmenu').selectmenu('menuWidget').addClass('els-options-list');
            $('.contact-counselor-city-selectmenu').selectmenu('widget').addClass('contact-counselor-selectmenu');
        }
        //--/Style Dropdown


        // Search ELS Centers
        // Summary:
        // When using the Find an ELS Center search, we need to reveal
        // the list of available options and reveal the item selected
        function searchCenters() {
            var searchBox = $('.search-center-search-textbox');
            var resultsList = $('.search-center-results-list');
            var resultItem = $('.search-center-results-list-item');
            var resultDetail = $('.search-center-result-detail');
            var closeResultDetail = $('.search-center-result-detail-close');
            var overviewDetail = $('.overview-detail');
            var overviewImage = $('.overview-content-image-wrapper-image');
            var overviewContent = $('.overview-content');

            // Click the drop down
            //$('.search-center-search-selectmenu').on('selectmenuselect', function (event, ui) {
            $(window).on('programSelected', function (e) {
                resultDetail.hide();
                showResultDetail();
                //ui.item.value // This is how you can get the value of the item selected
            });

            // Click the search box
            searchBox.on('focus', function (e) {
                //handle the goal clicking
                var value = "{548A7B11-2207-4F1E-94B7-19F71430D06C}";
                var goalurl = "/api/Sitecore/ELS/TriggerPageEvents";

                $.post(goalurl,
                    { goal: value },
                    function (data) {
                        //do nothing, no client interaction needed
                    }
                );

                e.preventDefault();
                //resultDetail.hide();
                resultsList.slideToggle();
            });

            // Click result item, show result detail
            resultItem.on('click', function (e) {
                e.preventDefault();
                showResultDetail();
            });
            $(window).on('centerSelected', function (e) {
                showResultDetail();
            });
            $(window).on('pricingResize', function (e) {
                if (!isMobileLayout) {
                    resultDetail.css({ display: 'block', positionLeft: '-999em' });
                    var resultDetailHeight = resultDetail.outerHeight() + 10;
                    //  resultDetail.removeAttr('style');

                    if (overviewDetail.css('margin-top').replace('px', '') != resultDetailHeight) {

                        overviewDetail.animate({ marginTop: resultDetailHeight });
                        overviewImage.addClass('overview-content-image-wrapper-image--active');
                        overviewImage.outerHeight(true);

                        var overviewDetailHeightPreResize = overviewDetail.outerHeight(true);
                        //var overviewDetailHeight = undefined;// overviewDetail.outerHeight(true);
                        //var overviewContentHeight = undefined;//overviewContent.outerHeight(true) + overviewImage.outerHeight(true);
                        var overviewDetailHeight = overviewDetail.outerHeight(false);
                        var overviewContentHeight = overviewContent.outerHeight(true);// + overviewImage.outerHeight(true);

                        equalHeight(overviewDetailHeight, overviewContentHeight);

                        //overviewDetail.css('height', (overviewDetail.outerHeight(true) - resultDetailHeight));
                        var proposedDetailHeight = overviewDetail.outerHeight(false) - resultDetailHeight;
                        if ((overviewDetailHeightPreResize - resultDetailHeight) == proposedDetailHeight) {
                            overviewDetail.css('height', (proposedDetailHeight));
                        }
                        else // ((overviewDetailHeightPreResize - resultDetailHeight) > proposedDetailHeight)
                        {
                            overviewDetail.css('height', (overviewDetailHeight));
                        }
                    }
                }
            });
            // Click close
            closeResultDetail.on('click', function (e) {
                resultDetail.slideToggle();
                resultsList.hide();
                if (!isMobileLayout) {
                    overviewDetail.animate({ marginTop: 10 });
                    overviewImage.removeClass('overview-content-image-wrapper-image--active');
                    overviewContent.add(overviewDetail).removeAttr("style");
                    equalHeight();
                }
            });

            function showResultDetail() {
                // Capture Result Detail height
                if (!isMobileLayout) {
                    resultDetail.css({ display: 'block', positionLeft: '-999em' });
                    var resultDetailHeight = resultDetail.outerHeight() + 10;
                    resultDetail.removeAttr('style');
                }

                resultDetail.slideToggle();

                // Move the program detail down
                if (!isMobileLayout) {
                    overviewDetail.animate({ marginTop: resultDetailHeight });
                    overviewImage.addClass('overview-content-image-wrapper-image--active');
                    overviewImage.outerHeight(true);

                    $(overviewDetail).css('height', 'auto');
                    $(overviewContent).css('height', 'auto');

                    var overviewDetailHeightPreResize = overviewDetail.outerHeight(true);
                    var overviewDetailHeight = overviewDetail.outerHeight(true);
                    var overviewContentHeight = overviewContent.outerHeight(true) + overviewImage.outerHeight(true);

                    equalHeight(overviewDetailHeight, overviewContentHeight);

                    var proposedDetailHeight = overviewDetail.outerHeight(false) - resultDetailHeight;

                    if (overviewDetailHeightPreResize > proposedDetailHeight) {
                        overviewDetail.css('height', (overviewDetailHeightPreResize));
                    }
                    else {
                        overviewDetail.css('height', (proposedDetailHeight));
                    }
                }

                resultsList.slideToggle();
            }
        }
        //--/Search ELS Centers

        // Program Levels
        // Summary:
        // When clicking the program levels, we need to expand and collapse the content
        // below it
        function programLevels() {
            var programLevel = $('.program-levels-item');
            var programLevelName = $('.program-levels-item-name');
            var openClass = 'program-levels-item--open';

            programLevel.first().addClass(openClass);
            programLevel.first().children('.program-levels-item-summary').slideDown();

            programLevelName.on('click', function (e) {
                e.preventDefault();

                if ($(this).parent('.program-levels-item').hasClass(openClass)) {
                    $(this).parent('.program-levels-item').removeClass(openClass);
                    $(this).siblings('.program-levels-item-summary').slideUp();



                }
                else {
                    if (!$(this).parent('.program-levels-item').hasClass('allow-all')) {

                        programLevel.removeClass(openClass);
                        programLevel.children('.program-levels-item-summary').slideUp();
                    }
                    $(this).parent('.program-levels-item').addClass(openClass)
                    $(this).siblings('.program-levels-item-summary').slideDown();

                }
            });
        }
        //--/ Program Levels
        //Expanding Teasers
        //Summary:
        //When clicking the expanding copy, Read More, we need to expand and collapse the copy
        function expandingCopy() {
            var epandingTeaserItem = $('.expanding-teaser-item');
            var epandingTeaserItemName = $('.expanding-teaser-item-name');
            var openClass = 'expanding-teaser-item--open';

            //epandingTeaserItem.first().addClass(openClass);
            //epandingTeaserItem.first().children('.expanding-teaser-item-summary').slideUp();

            epandingTeaserItemName.on('click', function (e) {
                e.preventDefault();

                if ($(this).parent('.expanding-teaser-item').hasClass(openClass)) {
                    $(this).parent('.expanding-teaser-item').removeClass(openClass);
                    $(this).siblings('.expanding-teaser-item-summary').slideUp();
                    epandingTeaserItemName.text('Read More').removeClass('expanding-teaser-item-name-less');
                }
                else {
                    epandingTeaserItem.removeClass(openClass);
                    epandingTeaserItem.children('.expanding-teaser-item-summary').slideUp();
                    $(this).parent('.expanding-teaser-item').addClass(openClass)
                    $(this).siblings('.expanding-teaser-item-summary').slideDown();
                    epandingTeaserItemName.text('Read More');
                    $(this).text('Less').addClass('expanding-teaser-item-name-less');
                }
            });
        }
        //Expanding Copy


        // Google Maps
        function initMap($latitude, $longitude, $zoomLevel, country, state, location) {
            if ($latitude == undefined)
                $latitude = '0.00';

            if ($longitude == undefined)
                $longitude = '0.00';

            if ($zoomLevel == undefined)
                $zoomLevel = 2;

            // Set google map options
            var map_options = {
                center: new google.maps.LatLng($latitude, $longitude),
                zoom: $zoomLevel,
                mapTypeControl: false,
                streetViewControl: false,
                scrollwheel: false,

                // Map Style
                // SnazzyMap: https://snazzymaps.com/style/151/ultra-light-with-labels
                styles: [{ "featureType": "water", "elementType": "geometry", "stylers": [{ "color": "#e9e9e9" }, { "lightness": 17 }] }, { "featureType": "landscape", "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }, { "lightness": 20 }] }, { "featureType": "road.highway", "elementType": "geometry.fill", "stylers": [{ "color": "#ffffff" }, { "lightness": 17 }] }, { "featureType": "road.highway", "elementType": "geometry.stroke", "stylers": [{ "color": "#ffffff" }, { "lightness": 29 }, { "weight": 0.2 }] }, { "featureType": "road.arterial", "elementType": "geometry", "stylers": [{ "color": "#ffffff" }, { "lightness": 18 }] }, { "featureType": "road.local", "elementType": "geometry", "stylers": [{ "color": "#ffffff" }, { "lightness": 16 }] }, { "featureType": "poi", "elementType": "geometry", "stylers": [{ "color": "#f5f5f5" }, { "lightness": 21 }] }, { "featureType": "poi.park", "elementType": "geometry", "stylers": [{ "color": "#dedede" }, { "lightness": 21 }] }, { "elementType": "labels.text.stroke", "stylers": [{ "visibility": "on" }, { "color": "#ffffff" }, { "lightness": 16 }] }, { "elementType": "labels.text.fill", "stylers": [{ "saturation": 36 }, { "color": "#333333" }, { "lightness": 40 }] }, { "elementType": "labels.icon", "stylers": [{ "visibility": "off" }] }, { "featureType": "transit", "elementType": "geometry", "stylers": [{ "color": "#f2f2f2" }, { "lightness": 19 }] }, { "featureType": "administrative", "elementType": "geometry.fill", "stylers": [{ "color": "#fefefe" }, { "lightness": 20 }] }, { "featureType": "administrative", "elementType": "geometry.stroke", "stylers": [{ "color": "#fefefe" }, { "lightness": 17 }, { "weight": 1.2 }] }]
            }

            // Initialize the map
            var map = new google.maps.Map(document.getElementById('map'), map_options);

            var infowindows = [];
            var markers = [];

            // Google Marker
            //var marker = new google.maps.Marker({
            //    position: new google.maps.LatLng($latitude, $longitude),
            //    map: map,
            //    icon: location.origin + '/images/map-marker.png'
            //});
            var infowindow = new google.maps.InfoWindow({
                content: "loading..."
            });
            if (typeof (window.mappoints) != 'undefined') {

                var filtered = $.grep(window.mappoints, function (n, i) {
                    var include = true;
                    if (typeof (country) != 'undefined' && country.length > 0) {
                        include = country == n.Country;
                        if (include && typeof (state) != 'undefined' && state.length > 0) {
                            include = state == n.StateLabel;
                            if (include && typeof (location) != 'undefined' && location.length) {
                                include = location == n.CenterGuid;
                            }
                        }
                    }
                    return include;
                });

                filtered = filtered.sort(function (a, b) {
                    if (a.CenterName < b.CenterName) return -1;
                    if (a.CenterName > b.CenterName) return 1;
                    return 0;
                })
                for (var i = 0; i < filtered.length; i++) {
                    var point = filtered[i];
                    var phone = "";
                    if (point.CenterName == "Sydney") {
                        phone = point.phone + "<br />";
                    }
                    var onCampusOf = "";
                    if (point.oncampusof.length > 0) {
                        onCampusOf = point.oncampusof + "<br />";
                    }

                    var marker = new google.maps.Marker({
                        position: new google.maps.LatLng(point.Latitude, point.Longitude),
                        map: map,

                        title: point.CenterName,
                        icon: '/images/map-marker.png',
                        html: "<div class='point-info'><strong> " + point.CenterName + "</strong><br/>"
                            + point.Address + "<br />"
                            + point.City + ", " + point.StateLabel + " " + point.Country + "<br />" + onCampusOf
                            + phone
                            + point.link
                            + "</div>"

                    });

                    google.maps.event.addListener(marker, 'click', function () {
                        infowindow.setContent(this.html);
                        infowindow.open(map, this);
                    });

                    google.maps.event.addListenerOnce(map, 'tilesloaded', function () {
                        if ($('.equal-height').length && !isMobileLayout) {
                            if (i == filtered.length - 1) {
                                equalHeight();
                            }
                        }
                    });

                    if (filtered.length == 1) {
                        infowindow.setContent(marker.html);
                        infowindow.open(map, marker);
                        map.setZoom(14);
                        map.setCenter(marker.position);
                    }
                }


                if (country != undefined && location == undefined) {

                    ShowCenterList(filtered, state == undefined);
                }
            }
        }//--/Google Maps

        // Change Program Center Selector
        // Summary:
        // When changing the Program Center selector, update the map and list results
        function changeCentersSelector() {
            var centerCountry = '';
            var centerLocation = '';

            $("#centers-selector-country").on("selectmenuchange", function (event, ui) {
                centerCountry = ui.item.value;


                $('.centers-map-selector-results').fadeOut();

                var geocoder = new google.maps.Geocoder();
                geocoder.geocode({ 'address': centerCountry }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        $latitude = results[0].geometry.location.lat();
                        $longitude = results[0].geometry.location.lng();

                        initMap($latitude, $longitude, 5, centerCountry);
                    }

                });


            });

            $("#centers-selector-location").on("selectmenuchange", function (event, ui) {
                centerLocation = ui.item.value;

                $('.centers-map-selector-results').fadeOut();

                var geocoder = new google.maps.Geocoder();
                geocoder.geocode({ 'address': centerLocation + ', ' + centerCountry }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        $latitude = results[0].geometry.location.lat();
                        $longitude = results[0].geometry.location.lng();

                        initMap($latitude, $longitude, 7, centerCountry, centerLocation);
                    }
                });
            });

            $('.centers-map-selector-results').on('click', 'a', function (e) {
                e.preventDefault();
                var country = $(this).attr('data-country');
                var state = $(this).attr('data-state');
                var id = $(this).attr('data-guid');
                var centers = $.grep(window.mappoints, function (el, index) {
                    return el.CenterGuid == id;
                });

                initMap(centers[0].Latitude, centers[0].Longitude, 12, country, state, id);
            });
        }

        function ShowCenterList(centers, fillstate) {
            if (fillstate != undefined && fillstate == true) {
                var states = $.map(centers, function (n) {
                    return n.StateLabel;
                });

                var distinctstates = $.grep(states, function (el, index) {
                    return index === $.inArray(el, states);
                }).sort();
                var options = [];
                for (i = 0; i < distinctstates.length; i++) {
                    options.push("<option value='" + distinctstates[i] + "'>" + distinctstates[i] + "</option>");
                }
                var statemenu = $("#centers-selector-location");

                statemenu.empty().append(options.join("")).selectmenu();
                statemenu.selectmenu('enable');

            }
            var ul1 = $("<ul class='centers-map-selector-results-left' />");

            var ul2 = $("<ul class='centers-map-selector-results-right' />");

            for (var i = 0; i < centers.length; i++) {
                var elt = $("<li><a href='#' data-country='" + centers[i].Country + "' data-state='" + centers[i].StateLabel + "' data-guid='" + centers[i].CenterGuid + "'>" + centers[i].CenterName + "</a></li>");

                if (i % 2 == 0) {
                    ul1.append(elt);
                } else {
                    ul2.append(elt);
                }
            }
            $('.centers-map-selector-results').empty().append(ul1);
            $('.centers-map-selector-results').append(ul2);
            $('.centers-map-selector-results').fadeIn();
        }

        //--/ FAQ links
        $(document).ready(function () {
            $(".faq-titles-link").click(function () {
                var id = $(this).attr('href');
                $(".faq-content-item").removeAttr("style");
                $(id).attr("style", "padding-top:150px;");
                
            });
            //$(document).mouseover(function () {
            //    $(".faq-content-item").removeAttr("style");
            //});
            var iScrollPos = 0;
            $(window).scroll(function () {
                var iCurScrollPos = $(this).scrollTop();
                if (iCurScrollPos > iScrollPos) {
                    //Scrolling Down
                } else {
                    $(".faq-content-item").removeAttr("style");
                }
                iScrollPos = iCurScrollPos;
            });
        });
        
        //--/ Change Program Center Selector


        // Filter Widget
        // Summary:
        // Clicking elements on the filter widget should filter and reveal sub menu (if any)
        function filterWidget() {
            var filterItem = $('.filter-widget-group-list-item');
            var clearFilters = $('.filter-widget-heading-clear-filter');

            filterItem.on('click', 'a', function (e) {

                var $elt = $(this).parent('li');

                if (/*$elt.children('ul').length || */$elt.parent().hasClass('filter-widget-group-list')) {
                    if ($elt.hasClass('filter-widget-group-list-item--active')) {
                        $elt.removeClass('filter-widget-group-list-item--active');
                        $elt.children('ul').hide();
                        $elt.siblings('li').show();
                    }
                    else {
                        $elt.addClass('filter-widget-group-list-item--active');
                        $elt.children('ul').show();
                        $elt.siblings('li').hide();
                    }
                }
                else {

                    if ($(this).hasClass('filter-widget-group-list-item--active')) {
                        $(this).removeClass('filter-widget-group-list-item--active');
                        $elt.siblings('li').show();
                    }
                    else {
                        $(this).addClass('filter-widget-group-list-item--active');
                        $elt.siblings('li').find('a').removeClass('filter-widget-group-list-item--active');
                        $elt.siblings('li').hide();
                    }
                }
            });

            clearFilters.on('click', function (e) {
                filterItem.removeClass('filter-widget-group-list-item--active');
            });
        }
        //--/ Filter Widget

        // Initialize Fancybox
        // Summary:
        // Initialize the fancybox modal for youtube videos
        function openFancybox() {
            if (isMobileLayout) {
                $(".fancybox-iframe").fancybox({
                    maxWidth: 800,
                    maxHeight: 600,
                    fitToView: false,
                    width: '90%',
                    height: '70%',
                    autoSize: false,
                    closeClick: false,
                    openEffect: 'none',
                    closeEffect: 'none',
                    type: 'iframe'
                });
            }
            else {
                $(".fancybox-iframe").fancybox({
                    maxWidth: 800,
                    maxHeight: 600,
                    fitToView: false,
                    width: '70%',
                    height: '70%',
                    autoSize: false,
                    closeClick: false,
                    openEffect: 'none',
                    closeEffect: 'none',
                    type: 'iframe'
                });
            }

        }//--/ Initialize Fancybox

        function openFancyHTMLVideo() {
            $(".previewHTMLVideo").fancybox({
                'beforeShow': function () {
                    $(window).on({
                        'resize.fancybox': function () {
                            $.fancybox.update();
                        }
                    });
                },
                'afterClose': function () {
                    $(window).off('resize.fancybox');
                },
                width: '640',
                height: '360',
                fitToView: true,
                closeClick: false,
                openEffect: 'none',
                closeEffect: 'none',
                closeBtn: 'true',
                scrolling: 'no',
            });
        }

        var layout = {};

        var SetDirection = function () {
            if ($('html').hasClass('rtl')) {
                layout.rtl = true;

                var styleSheets = document.styleSheets;
                var modifyRule = function (rule) {
                    if (rule.style.getPropertyValue(layout.rtl ? 'left' : 'right') && rule.selectorText.match(/\.col-(xs|sm|md|lg)-push-\d\d*/)) {
                        rule.style.setProperty((layout.rtl ? 'right' : 'left'), rule.style.getPropertyValue((layout.rtl ? 'left' : 'right')));
                        rule.style.removeProperty((layout.rtl ? 'left' : 'right'));
                    }
                    if (rule.style.getPropertyValue(layout.rtl ? 'right' : 'left') && rule.selectorText.match(/\.col-(xs|sm|md|lg)-pull-\d\d*/)) {
                        rule.style.setProperty((layout.rtl ? 'left' : 'right'), rule.style.getPropertyValue((layout.rtl ? 'right' : 'left')));
                        rule.style.removeProperty((layout.rtl ? 'right' : 'left'));
                    }
                    if (rule.style.getPropertyValue(layout.rtl ? 'margin-left' : 'margin-right') && rule.selectorText.match(/\.col-(xs|sm|md|lg)-offset-\d\d*/)) {
                        rule.style.setProperty((layout.rtl ? 'margin-right' : 'margin-left'), rule.style.getPropertyValue((layout.rtl ? 'margin-left' : 'margin-right')));
                        rule.style.removeProperty((layout.rtl ? 'margin-left' : 'margin-right'));
                    }
                    if (rule.style.getPropertyValue('float') && rule.selectorText.match(/\.col-(xs|sm|md|lg)-\d\d*/)) {
                        rule.style.setProperty('float', (layout.rtl ? 'right' : 'left'));
                    }
                };
                try {
                    for (var i = 0; i < styleSheets.length; i++) {
                        var rules = styleSheets[i].cssRules || styleSheets[i].rules;
                        if (rules) {
                            for (var j = 0; j < rules.length; j++) {
                                if (rules[j].type === 4) {
                                    var mediaRules = rules[j].cssRules || rules[j].rules
                                    for (var y = 0; y < mediaRules.length; y++) {
                                        modifyRule(mediaRules[y]);
                                    }
                                }
                                if (rules[j].type === 1) {
                                    modifyRule(rules[j]);
                                }

                            }
                        }
                    }
                } catch (e) {
                    // Firefox might throw a SecurityError exception but it will work
                    if (e.name !== 'SecurityError') {
                        throw e;
                    }
                }
            }
        };

        var smoothScroll = function () {
            $('a[href*="#"]:not([href="#"])').not('[role="tab"]').not('[role="button"]').click(function () {
                if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
                    var target = $(this.hash);
                    target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                    if (target.length) {
                        $('html, body').animate({
                            scrollTop: target.offset().top
                        }, 1000);
                        return false;
                    }
                }
            });

        };

        // Explicitly return public methods when this object is instantiated
        return {
            initMobileNavigation: mobileNavigation,
            initMoveUtility: moveUtilityNav,
            initBrowserResize: browserResize,
            initGenerateSubNavLinks: generateSubNavLinks,
            initParentMenuItem: parentMenuItem,
            initHeroSlider: hero,
            initStudentQuoteSlider: studentQuote,
            initFooterNavigation: footerNavigation,
            initGoalTracking: goalTracking,
            initUtilityNavSelector: utilityNavSelector,
            initStyleDropdown: styleDropdown,
            initSearchCenters: searchCenters,
            initProgramLevels: programLevels,
            initExpandingCopy: expandingCopy,
            initChangeCentersSelector: changeCentersSelector,
            initMap: initMap,
            initFilterWidget: filterWidget,
            initOpenFancybox: openFancybox,
            initOpenFancyHTMLVideo: openFancyHTMLVideo,
            initDirection: SetDirection,
            initSmoothScroll: smoothScroll
        };

    })(window);
    //--/ ELS Module

    //RTL Code

    //Mobile only code
    //if (isMobileLayout) {
    ELS.initMoveUtility();
    ELS.initMobileNavigation();

    //}//--/Mobile only code
    ELS.initBrowserResize();
    ELS.initFooterNavigation();
    ELS.initGoalTracking();
    ELS.initGenerateSubNavLinks();
    ELS.initParentMenuItem();
    ELS.initHeroSlider();
    ELS.initStudentQuoteSlider();
    ELS.initUtilityNavSelector();
    ELS.initStyleDropdown();
    ELS.initSearchCenters();
    ELS.initProgramLevels();
    ELS.initExpandingCopy();
    ELS.initChangeCentersSelector();
    ELS.initFilterWidget();
    ELS.initOpenFancybox();
    ELS.initOpenFancyHTMLVideo();
    ELS.initDirection();
    ELS.initSmoothScroll();
    if ($('#map').length) {
        ELS.initMap();
    }

    // Equal Height
    if ($('.equal-height').length && !isMobileLayout) {
        equalHeight();
    }
    //--/Equal Height

    //var $getstarted = $('section.get-started');

    //if ($getstarted.length > 0 && $('.last-section').length == 0) {
    //    var $prev = $getstarted.siblings('section').last();
    //    if (!$prev.hasClass('why-els')) {
    //        $prev.addClass('last-section');
    //    }

    //}

});

//// Equal Height
//// Summary:
//// Set all elements with the class 'equal-height' to the same height
//// of the tallest element
jQuery(window).resize(function () {
    jQuery(window).trigger('browserResize');
    ////resize just happened, pixels changed
    //var mobileButton = jQuery('.navigation-button');
    //var isMobileLayout = mobileButton.is(':visible');
    //if (isMobileLayout) {
    //    moveUtilityNav();
    //    jQuery('.equal-height').css('height', 'auto');
    //}

});
//jQuery('.equal-height').resize(equalHeight());
function equalHeight(heightOne, heightTwo) {
    var tallestHeight = 0;

    if (heightOne == undefined || heightTwo == undefined) {
        jQuery('.equal-height').each(function () {
            if (jQuery(this).outerHeight(true) > tallestHeight)
                tallestHeight = jQuery(this).outerHeight(true);
        });
    }
    else {
        if (heightOne > heightTwo) {
            tallestHeight = heightOne;
        }
        else {
            tallestHeight = heightTwo;
        }
    }

    jQuery('.equal-height').css('height', tallestHeight);
}

// Move Utility Nav
// Summary:
// For mobile, move the utility nav below the main navigation and search.
// We also need to move the language selector below the utility navigation menu.
//function moveUtilityNav() {
//    var utilityNav = jQuery('.header-navigation-utility');
//    var utilitySelector = jQuery('.header-navigation-utility-selector');
//    var navigation = jQuery('.header-navigation');


//    //if (isMobileLayout) {
//        utilityNav.appendTo(navigation);
//        utilitySelector.appendTo(navigation);
//        ELS.initMobileNavigation();
//    //}
//}
//--/ Move Utility Nav

jQuery('div.accordion .accordion-title').click(function () {
    jQuery(this).toggleClass("active");
    jQuery(this).next('div.accordion div.content-container').slideToggle('normal');
    if (jQuery(this).parent('div.accordion').hasClass('login')) {
        jQuery('div.accordion.register').find('div.content-container').slideUp('normal')
        jQuery('div.accordion.register').find('h2.accordion-title').removeClass('active');
        jQuery("#letter-example").fadeOut(200);
    }
    if (jQuery(this).parent('div.accordion').hasClass('register')) {
        jQuery('div.accordion.login').find('div.content-container').slideUp('normal')
        jQuery('div.accordion.login').find('h2.accordion-title').removeClass('active');
    }
});
jQuery('p.accordion-open a').click(function (e) {
    e.preventDefault();
    if (jQuery(this).hasClass('opened')) {
        jQuery(this).text('Open Forms').removeClass('opened');
        jQuery('.accordion-title').removeClass('active');
        jQuery('div.accordion div.content-container').slideUp('normal');
    } else {
        jQuery(this).text('Close Forms').addClass('opened');
        jQuery('.accordion-title').addClass('active');
        jQuery('div.accordion div.content-container').slideDown('normal');
    }
});


// Squishy header

/*!
 * classie - class helper functions
 * from bonzo https://github.com/ded/bonzo
 * 
 * classie.has( elem, 'my-class' ) -> true/false
 * classie.add( elem, 'my-new-class' )
 * classie.remove( elem, 'my-unwanted-class' )
 * classie.toggle( elem, 'my-class' )
 */

/*jshint browser: true, strict: true, undef: true */
/*global define: false */

(function (window) {

    'use strict';

    // class helper functions from bonzo https://github.com/ded/bonzo

    function classReg(className) {
        return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
    }

    // classList support for class management
    // altho to be fair, the api sucks because it won't accept multiple classes at once
    var hasClass, addClass, removeClass;

    if ('classList' in document.documentElement) {
        hasClass = function (elem, c) {
            return elem.classList.contains(c);
        };
        addClass = function (elem, c) {
            elem.classList.add(c);
        };
        removeClass = function (elem, c) {
            elem.classList.remove(c);
        };
    }
    else {
        hasClass = function (elem, c) {
            return classReg(c).test(elem.className);
        };
        addClass = function (elem, c) {
            if (!hasClass(elem, c)) {
                elem.className = elem.className + ' ' + c;
            }
        };
        removeClass = function (elem, c) {
            elem.className = elem.className.replace(classReg(c), ' ');
        };
    }

    function toggleClass(elem, c) {
        var fn = hasClass(elem, c) ? removeClass : addClass;
        fn(elem, c);
    }

    var classie = {
        // full names
        hasClass: hasClass,
        addClass: addClass,
        removeClass: removeClass,
        toggleClass: toggleClass,
        // short names
        has: hasClass,
        add: addClass,
        remove: removeClass,
        toggle: toggleClass
    };

    // transport
    if (typeof define === 'function' && define.amd) {
        // AMD
        define(classie);
    } else {
        // browser global
        window.classie = classie;
    }

})(window);


/**
 * cbpAnimatedHeader.min.js v1.0.0
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2013, Codrops
 * http://www.codrops.com
 */
var cbpAnimatedHeader = (function () { var b = document.documentElement, g = document.querySelector(".header"), e = false, a = 300; function f() { d(); window.addEventListener("scroll", function (h) { if (!e) { e = true; setTimeout(d, 250) } }, false) } function d() { var h = c(); if (h >= a) { classie.add(g, "cbp-af-header-shrink") } else { classie.remove(g, "cbp-af-header-shrink") } e = false } function c() { return window.pageYOffset || b.scrollTop } f() })();

//els-news-feed
jQuery(document).ready(function ($) {

    $(".Els-latest-news-item").mouseover(function () {
        $(this).find(".Els-hovermouse-new").hide();
        $(this).find(".Els-news-label").hide();
        $(this).find(".Els-news-label-info").hide();
        $(this).find("a.Els-news-hoverlink").show();
        (".Els-latest-news-item").anchor();
        $(this).css("cursor", "pointer");
        var imageurl = $(this).attr("data-id");
        $(this).css("background-image", "url(" + imageurl + ")");
        $(this).css("background-color", "#0086b9", "background-size", "cover", "background-repeat", "no-repeat", "background-position", "enter");
    })
   .mouseout(function () {
       $(this).find(".Els-hovermouse-new").show();
       $(this).find(".Els-news-label").show();
       $(this).find(".Els-news-label-info").show();
       $(this).find("a.Els-news-hoverlink").hide();
       $(this).css("background-image", "");
       $(this).css("background-color", "#00a5df");
   })

    $(".Els-latest-news-item").click(function () {

        window.location = $(this).find("a").attr("href");


    })

});