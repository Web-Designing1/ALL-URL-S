﻿(function (window, $) {
    "use strict";
    
    $(window.document).ready(function () {

    var nocache = new Date().getTime();

    //global search
    $("#global-search").select2({
        placeholder: "Search for University, Major, or Interest",
        minimumInputLength: 1,
        openOnEnter: false,
        query: function (query) {
            var data = {
                query: query.term
            };
            clearTimeout($(this).data('timer'));
            $(this).data('timer', setTimeout(function () {
                $.get("/api/sitecore/Partners/Global", data, function (results) {
                    query.callback(results);
                });
            }, 300));
            //$("#global-search").select2("close");
        }
    });

    $(".field-validation").hide();


    $("#global-search").on("select2-selecting", function (e) {
        var data = e.object;
        submitGlobalSearch(data);
    });

    $("#btn-global-search").click(function () {
        var data = $("#global-search").select2("data");
        submitGlobalSearch(data);

        return false;
    });

    $('#aGIWSearch').click(function () {
        $("#global-search-cat").val("oneclicksearch");
        $("#global-search-val").val($(this).attr("data-type"));
        $("#global-search-val1").val("Masters");
        //$('#home-search-load-modal').modal('show');loadingsearchmodal
        //$('.loadingsearchmodal').modal('show');
        $("#global-search-from").submit();
        return false;
    });

    //$("#languageSelect").change(function () {
    //    window.location = "/Language/Change?language=" + $(this).val();
    //});

    //$("#s2id_global-search").click(function () {
    //    $("#logged-out-menu").slideUp();
    //    $("#counselorlogged-out-menu").slideUp();
    //});


    //build the language selection dropdown
    //$.ajax({
    //    type: "GET",
    //    cache: false,
    //    url: "/api/sitecore/Partners/GetLanguageList?ch=" + nocache,
    //    success: function (result) {
    //        var $langs = $('#languageSelect');
    //        $langs.empty();
    //        $(result).each(function () {
    //            $("<option />", {
    //                val: this.id,
    //                text: this.name,
    //                selected: this.selected
    //            }).appendTo($langs);
    //        });
    //        //$langs.selectpicker('refresh');
    //    }
    //});
});
    
$(document).on("change", 'select[data-validate="true"]', function () {
    var selector = $(this);
    var $validation = selector.parent().next(".field-validation");
    if (selector.val().length > 0 && selector.val() != "") {
        $validation.find(".error").hide();
        $validation.find(".saved").show();
        $validation.show();
        $('button[data-id="' + $(this).attr("id") + '"]').removeClass("validate-error");
    }
    else {
        $validation.find(".error").show();
        $validation.find(".saved").hide();
        //$validation.show();
        $('button[data-id="' + $(this).attr("id") + '"]').addClass("validate-error");
    }
});

function validateSelect(fieldItems) {
    var valid = true;
    jQuery.each(fieldItems, function (index, item) {
        var $item = $("#" + item);
        var $validation = $item.parent().next(".field-validation");
        $validation.show();
        if ($item.val().length <= 0) {
            $('button[data-id="' + $item.attr("id") + '"]').addClass("validate-error");
            $validation.find(".error").show();
            $validation.find(".saved").hide();
            valid = false;
        } else {
            $('button[data-id="' + $item.attr("id") + '"]').removeClass("validate-error");
            $validation.find(".error").hide();
            $validation.find(".saved").show();
        }
    });

    return valid;
}

function submitGlobalSearch(data) {
    if (data.text == $("#view-more-text").val()) {
        //window.location = "/Search/ViewMore?query=" + data.id + "&cat=" + data.category;
        window.open("https://www.universityguideonline.org/Search/ViewMore?query=" + data.id + "&cat=" + data.category);
    } else {
        $("#global-search-val").val(data.id);
        $("#global-search-cat").val(data.category);
        $("#global-search-text").val(data.text);
        $("#global-search-type").val("global");
        //$('#top-search-load-modal').modal('show');

        $("#global-search-from").submit();
    }
}
})(window, jQuery);
