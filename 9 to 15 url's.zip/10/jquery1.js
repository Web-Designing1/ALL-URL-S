$(function(){
  $('#header_nav').data('size','big');
});

$(window).on('resize',function(){window.location=window.location;});
var windowWidth = $(window).width();
if(windowWidth > 997) {
$(window).scroll(function(){
	
  if($(document).scrollTop() > 250)
{
    if($('#header_nav').data('size') == 'big')
    {
        $('#header_nav').data('size','small');
        $('#header_nav').stop().animate({
            height:'90px'
        },);
        /*$('#logo').attr('src','logo-mobile.png');*/
        $('#logo').addClass("sml-logo");
        $('#langbtn').hide();
        $('#myels_link').hide();
        $('#srch').hide();
        $('#destination').addClass("sml-dest");
    }
}
else
  {
    if($('#header_nav').data('size') == 'small')
      {
        $('#header_nav').data('size','big');
        $('#header_nav').stop().animate({
            height:'130px'
        },);
        /* $('#logo').attr('src','els-logo.png'); */
        $('#logo').removeClass("sml-logo");
        $('#langbtn').show();
        $('#myels_link').show();
        $('#srch').show();
        $('#destination').removeClass("sml-dest");
      }  
  }
});
}



