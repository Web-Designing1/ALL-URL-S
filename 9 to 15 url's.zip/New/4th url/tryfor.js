function titleValidate(){
var title=document.form.title;
if(title.value==""){
document.getElementById("title").innerHTML="The title field is required.";
document.form.title.className="fail";
return false;
}
else{
document.getElementById("title").innerHTML="";
document.form.title.className="check";
return true;}}

function genderValidate(){
var gender=document.form.gender;
if(gender.value=="")
{
document.getElementById("gender").innerHTML="You need to check this fields.";
gender.className="fail";
return false;}
else{
document.getElementById("gender").innerHTML="";
gender.className="check";
return true;}}

function firstnameValidate(){
var fname=document.form.firstname;
if(fname.value=="")
{
document.getElementById("firstname").innerHTML="This field is needed.";
document.getElementById("firstname").style.color="brown";
fname.className="fail";
return false;}
else{
document.getElementById("firstname").innerHTML="";
fname.className="check";
return true;
}
}

function familynameValidate(){
var fmname=document.form.familyname;
if(fmname.value==""){
document.getElementById("familyname").innerHTML="This field is needed.";
document.getElementById("familyname").style.color="brown";
fmname.className="fail";
return false;}
else{
document.getElementById("familyname").innerHTML="";
fmname.className="check";
return true;}}

function  emailValidate(){
		    var email = document.getElementById('em');
			 var emails =/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
			if(email==""||!emails.test(email.value))
			{
				document.getElementById("email").innerHTML="This field is needed.";
				document.getElementById("email").style.color="brown";

				 		email.className="fail";

				return false;
			}
			else{
				document.getElementById("email").innerHTML="";
				email.className="check";

				return true;
			}
		}


function phonenumberValidate(){
			var phonenumber=document.getElementById('tel');
			var phoneno=/^(7|8|9)\d{9}$/;
				if(phonenumber==""||!phoneno.test(phonenumber.value)){
				document.getElementById("phonenumber").innerHTML="This field is needed.";
				 document.getElementById("phonenumber").style.color="brown";
phonenumber.className="fail";

				return false;
			}else {
				document.getElementById("phonenumber").innerHTML="";
phonenumber.className="check";

				return true;
			}
		}

function mobileValidate(){
			var mobile=document.getElementById('mo');
			var mobilep=/^\d{3}-\d{3}-\d{4}$/;
				if(mobile==""||!mobilep.test(mobile.value)){
				document.getElementById("mobilea").innerHTML="This field is needed.";
				 document.getElementById("mobilea").style.color="brown";
mobile.className="fail";

				return false;
			}else {
				document.getElementById("mobilea").innerHTML="";
mobile.className="check";

				return true;
			}
		}

function countriesValidate(){
var countrie=document.form.countries;
if(countrie.value==""){
countrie.className="fail";}
else{
countrie.className="check";}
}

function nationalityValidate(){
var  nation=document.form.nationality;
if(nation.value==""){
nation.className="fail";}
else{
nation.className="check";}
}
function passportValidate(){
var passport=document.form.passport;
if(passport.value==""){
passport.className="fail";}
else{
passport.className="check";}
}

function firstlanguageValidate(){
var firstl=document.form.firstlanguage;
if(firstl.value==""){
firstl.className="fail";}
else{
firstl.className="check";
}}

function otherValidate(){document.form.other.className="check";
}

function dateValidate(){document.form.dat.className="check";}

function addressoneValidate(){document.form.addressone.className="check";}

function addresstwoValidate(){document.form.addresstwo.className="check";}

function cityValidate(){document.form.cit.className="check";}

function stateValidate(){document.form.state.className="check";}

function postValidate(){document.form.postcode.className="check";}

function countryValidate(){document.form.country.className="check";}

function ausaddValidate(){document.form.ausadd.className="check";}

function ausaddtwoValidate(){document.form.ausaddtwo.className="check";}

function auscityValidate(){document.form.auscity.className="check";}

function ausstateValidate(){document.form.ausstate.className="check";}

 function auspostValidate(){document.form.auspost.className="check";}

function australi(){
document.form.australia.className="check";}

function courseValidate(){
document.form.coursedate.className="check";}

function weeksValidate(){
document.form.weeks.className="check";
}

function levelValidate(){
var level=document.form.level;
if(level.value==""){
return false;}
else{level.className="check";
return true;}
}

function textareaValidate(){
var area=document.form.area;
if(area.value==""){
return false;
}else{area.className="check";
return true;
}
}

function educationValidate(){
var education=document.form.education;
if(education.value==""){
return false;
}
else{
education.className="check";
return true;}
}

function checkvalidate(){
var check=document.form.check;
var span=document.form.study;
if(check.value==""){
return false;
}
else{
 span.value.style.color="green";
return true;
}
}

 function servicesValidate(){
var service=document.form.services;
if(service.value==""){
return false;
}
else{
service.className="check";
return true;
}
}

 function englishcourseValidate(){
var english=document.form.englishcourse;
if(english.value==""){
return false;
}
else{
english.className="check";
}
}

function elsValidate(){
var els=document.form.ELS;
if(els.value==""){
return false;}
else{
els.className="check";
}
}

function agentnameValidate(){
var agentname=document.form.agentname;
if(agentname.value==""){
return false;}
else{
agentname.className="check";
return true;
}
}

function visaValidate(){
var visa=document.form.visa;
if(visa.value==""){
return false;}
else{
visa.className="check";
return true;
}
}

function presentValidate(){
var present=document.form.present;
if(present.value==""){
return false
}
else{
present.className="check";
return true;
}
}

function airportValidate(){
var airport=document.form.airport;
if(airport.value==""){
return false;
}
else{
airport.className="check";
return true;
}
}

function accommodationValidate(){
var accom=document.form.accommodation;
if(accom.value==""){
return false;}
else{
accom.className="check";
return true;}
}

function medicalValidate(){
var medical=document.form.medi;
if(medical.value==""){
return false
}
else{
medical.className="resizearea";
return true;
}
}

function ageValidate(){
var age=document.form.age;
if(age.value==""){
return false;
}
else{
age.className="check";
return true;
}
}

function termsValidate(){
var condition=document.form.conditions;
if(condition.value==""){document.getElementById("conditions").innerHTML="The Terms and conditions field is required.";
document.getElementById("conditions").style.color="brown";
return false;}
else{
document.getElementById("conditions").innerHTML="";
return true;
}
}
