
function resizeHeaderOnScroll() {
 const distanceY = window.pageYOffset || document.documentElement.scrollTop,
 shrinkOn = 300,
 headerEl = document.getElementById('header');  
 if (distanceY > shrinkOn) {
   headerEl.classList.add("smaller");
 } else {
   headerEl.classList.remove("smaller");
 }
}
window.addEventListener('scroll', resizeHeaderOnScroll);

function submitL()
{
	var first=document.submission.first.value;
	var last=document.submission.last.value;
	var email=document.submission.email.value;
	var phone=document.submission.phone.value;
	var ch=document.submission.ch.value;
	var year=document.submission.year.value;
	var ch1=document.submission.ch1.value;
	var check=document.submission.check.value;
	var gender=document.submission.gender.value;
	var ch2=document.submission.ch2.value;

	if(first && last && email && phone && ch && year && ch1 && check && gender && ch2)
	{
		return true;
}
else
{
	nameF();
	lastN();
	mailE();
	phoneP();
	charP();
	yearK();
	testC();
	itS();
	testD();
	validateFormGender();
	    errorMessageDisplay();

}
		return false;
	
}

function nameF()
{
	var first=document.submission.first;
	if(first.value=="")
	{
		document.getElementById("f").innerHTML="The First Name field is required.";
		document.getElementById("f").style.color="#AF4E45";
				document.submission.first.className="wrong";

		return false;
	}
	else
	{
		document.getElementById("f").innerHTML="";
		document.submission.first.className="tick";

		return true;
	}
}


function lastN()
{
	var last=document.submission.last;
	if(last.value=="")
	{
		document.getElementById("l").innerHTML="The Last Name/ Family Name field is required.";
						document.getElementById("l").style.color="#AF4E45";
				document.submission.last.className="wrong";

		return false;
	}
	else
	{
		document.getElementById("l").innerHTML="";
						document.submission.last.className="tick";

		return true;
	}
}
		function mailE(){
		    var email = document.getElementById('mail');
			 var emails =/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
			if(email==""||!emails.test(email.value))
			{
				document.getElementById("Mail").innerHTML="The Email field is required.";
				 document.getElementById("Mail").style.color="#AF4E45";
				 		document.submission.email.className="wrong";

				return false;
			}
			else{
				document.getElementById("Mail").innerHTML="";
				document.submission.email.className="tick";

				return true;
			}
		}
	function phoneP(){
			var phone=document.getElementById('ph');
			var phoneno=/^(7|8|9)\d{9}$/;
				if(phone==""||!phoneno.test(phone.value)){
				document.getElementById("p").innerHTML="The Phone Number/ Mobile Number field is required.";
				 document.getElementById("p").style.color="#AF4E45";
				 document.submission.phone.className="wrong";

				return false;
			}else {
				document.getElementById("p").innerHTML="";
								 document.submission.phone.className="tick";

				return true;
			}
		}

function charP()
{
	var ch=document.submission.ch;
	if(ch.value=="")
	{
		document.getElementById("ch1").innerHTML="The Country of residence field is required.";
						document.getElementById("ch1").style.color="#AF4E45";
				 document.submission.ch.className="wrong";

		return false;
	}
	else
	{
		document.getElementById("ch1").innerHTML="";
						 document.submission.ch.className="tick";

		return true;
	}
}

	function yearK(){
			var year=document.getElementById('yr1');
			var phoneno=/^(1)\d{3}$/;
				if(year==""||!phoneno.test(year.value)){
				document.getElementById("yr").innerHTML="The Year Born field is required.";
				 document.getElementById("yr").style.color="#AF4E45";
				 document.submission.year.className="wrong";

				return false;
			}else {
				document.getElementById("yr").innerHTML="";
			 document.submission.year.className="tick";

				return true;
			}
		}
		function testC()
		{
			var ch1=document.submission.ch1;
			if(ch1.value=="")
			{
				document.getElementById("chid").innerHTML="The What do you need help with? field is required.";
			document.submission.ch1.className="wrong";
document.getElementById("chid").style.color="#AF4E45";
				return false;
			}
			else
			{
				document.getElementById("chid").innerHTML="";
							document.submission.ch1.className="tick";

				return true;
			}
		}
		function validateFormGender() {
	if(document.submission.gender.value==""){
		document.getElementById("gender1").innerHTML="The Gender field is required.";
		document.getElementById("gender1").className="property";
		document.getElementById("male").style.color="#a94442";
		document.getElementById("fmale").style.color="#a94442";
		
		return false;
		}
	else{
		document.getElementById("gender1").innerHTML="";
		document.getElementById("male").style.color="#007722";
		document.getElementById("fmale").style.color="#007722";
		return true;
		}
	}

function itS()
		{
			var check=document.submission.check;
			if(check.value=="")
			{
				document.getElementById("res").innerHTML="The Terms And Conditions field is required.";
							document.submission.check.className="wrong";
		document.getElementById("res").style.color="#AF4E45";

				return false;
			}
			else
			{
				document.getElementById("res").innerHTML="";
			document.submission.check.className="tick";

				return true;
			}
		}
		function testD()
		{
			var ch2=document.submission.ch2;
			if(ch2.value=="")
			{
				document.getElementById("iest").innerHTML="The Center of Interest field is required.";
							document.submission.ch2.className="wrong";
		document.getElementById("iest").style.color="#AF4E45";

				return false;
			}
			else
			{
				document.getElementById("iest").innerHTML="";
			document.submission.check.className="tick";

				return true;
			}
		}
			  function errorMessageDisplay() {
	var list="";
	if(nameF() && lastN() && mailE() && phoneP() && charP() &&  yearK() && testC()) {
		document.getElementById("errorMessage").innerHTML="";
		document.getElementById("errorMessage").className="error_message1";
		return true;
		}
	else {
		document.getElementById("errorMessage").className="error_message";
		if(!nameF()) {
			list=list + "<li>" + document.getElementById("f").innerHTML + "</li>";
			}
		if(!lastN()) {
			list=list + "<li>" + document.getElementById("l").innerHTML + "</li>";
			}
		if(!mailE()) {
			list=list + "<li>" + document.getElementById("Mail").innerHTML + "</li>";
			}
		if(!phoneP()) {
			list=list + "<li>" + document.getElementById("p").innerHTML + "</li>";
			}
		if(!charP()) {
			list=list + "<li>" + document.getElementById("ch1").innerHTML + "</li>";
			}
		if(!yearK()) {
			list=list + "<li>" + document.getElementById("yr").innerHTML + "</li>";
			}
		if(!testC()) {
			list=list + "<li>" + document.getElementById("chid").innerHTML + "</li>";
			}
			
			if(!itS()) {
			list=list + "<li>" + document.getElementById("res").innerHTML + "</li>";
			}
					if(!testD()) {
			list=list + "<li>" + document.getElementById("iest").innerHTML + "</li>";
			}
		document.getElementById("errorMessage").innerHTML=list;
		return false;
		}
	}
 

		
	
