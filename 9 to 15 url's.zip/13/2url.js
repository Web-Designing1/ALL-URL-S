function funSub()
{
	var fname=document.form1.fname.value;
	var lname=document.form1.lname.value;
	var email=document.form1.email.value;
	var phne=document.form1.phne.value;
	var inter=document.form1.inter.value;
	var degreeID=document.form1.degreeID.value;
	var state=document.form1.state.value;
	var gen=document.form1.gen.value;
	var sel=document.form1.sel.value;
	var cu=document.form1.cu.value;

	if(fname && lname && email && phne && inter && degreeID && state && gen && sel && cu)
	{
		return true;
}
else
{
	firstN();
	lastN();
	eM();
	phneP();
	interI();
	tColor();
	changeT();
	genM();
	selS();
	ccC();
	
	    

}
		return false;
	
}

function firstN()
{
	var fname=document.form1.fname;
	if(fname.value=="")
	{
		document.getElementById("fn").style.borderColor="red";

		return false;
	}
	else
	{
		document.getElementById("fn").style.borderColor="white";

		return true;
	}
}


function lastN()
{
	var lname=document.form1.name;
	if(lname.value=="")
	{
			document.getElementById("ln").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("ln").style.borderColor="white";

		return true;
	}
}

		function eM(){
		    var email = document.getElementById('em');
			 var emails =/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	
			if(email==""||!emails.test(email.value))
			{
						document.getElementById("em").style.borderColor="red";


				return false;
			}
			else{
										document.getElementById("em").style.borderColor="white";

				return true;
			}
		}
	function phneP(){
			var phne=document.getElementById('ph');
			var phoneno=/^(7|8|9)\d{9}$/;
				if(phne==""||!phoneno.test(phne.value)){
					document.getElementById("ph").style.borderColor="red";


				return false;
			}else {
									document.getElementById("ph").style.borderColor="white";


				return true;
			}
		}

function interI()
{
	var inter=document.form1.inter;
	if(inter.value=="")
	{
			document.getElementById("int").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("int").style.borderColor="white";

		return true;
	}
}
function tColor()
{
	var degreeID=document.form1.degreeID;
	if(degreeID.value=="")
	{
			document.getElementById("deg").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("deg").style.borderColor="white";

		return true;
	}
}
function changeT()
{
	var state=document.form1.state;
	if(state.value=="")
	{
			document.getElementById("st").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("st").style.borderColor="white";

		return true;
	}
}
function genM()
{
	var gen=document.form1.gen;
	if(gen.value=="")
	{
			document.getElementById("ge").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("ge").style.borderColor="white";

		return true;
	}
}
function selS()
{
	var sel=document.form1.sel;
	if(sel.value=="")
	{
			document.getElementById("se").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("se").style.borderColor="white";

		return true;
	}
}
function ccC()
{
	var cu=document.form1.cu;
	if(cu.value=="")
	{
			document.getElementById("cc").style.borderColor="red";


		return false;
	}
	else
	{
		document.getElementById("cc").style.borderColor="white";

		return true;
	}
}

