function validateForm() {
	var fname=document.myForm.fname.value;
	var lname=document.myForm.lname.value;
	var gender=document.myForm.gender.value;
	var email=document.myForm.email.value;
	var phone=document.myForm.number.value;
	var country=document.myForm.country.value;
	var year=document.myForm.year.value;
	var help=document.myForm.help.value;
	var study=document.myForm.study.value;
	var center=document.myForm.center.value;
	var check=document.myForm.check.value;
	if(fname && lname && gender && email && phone && country && year && help && study && center && check) {
		return true;
		}
	else {
		fnameValidate();
		lnameValidate();
		genderValidate();
		emailValidate();
		phoneValidate();
		countryValidate();
		yearValidate();
		helpValidate();
		studyValidate();
		centerValidate();
		validateFormCheck();
		errorMessageDisplay();
		}
		return false;
			}	
			
function errorMessageDisplay() {
	var list="";
	if(fnameValidate() && lnameValidate() && genderValidate() && emailValidate() && phoneValidate() && countryValidate() && yearValidate() && helpValidate() && studyValidate() && centerValidate() && validateFormCheck()) {
		document.getElementById("error_message").innerHTML="";
		document.getElementById("error_message").className="error_message1";
		return true;
		}
	else {
		document.getElementById("error_message").className="error_message";
		if(!fnameValidate()) {
			list=list + "<li>" + document.getElementById("first").innerHTML + "</li>";
			}
		if(!lnameValidate()) {
			list=list + "<li>" + document.getElementById("last").innerHTML + "</li>";
			}
		if(!genderValidate()) {
			list=list + "<li>" + document.getElementById("gendero").innerHTML + "</li>";
			}
		if(!emailValidate()) {
			list=list + "<li>" + document.getElementById("Email").innerHTML + "</li>";
			}
		if(!phoneValidate()) {
			list=list + "<li>" + document.getElementById("Phone").innerHTML + "</li>";
			}
		if(!countryValidate()) {
			list=list + "<li>" + document.getElementById("Country").innerHTML + "</li>";
			}
		if(!yearValidate()) {
			list=list + "<li>" + document.getElementById("Year").innerHTML + "</li>";
			}
		if(!helpValidate()) {
			list=list + "<li>" + document.getElementById("Help").innerHTML + "</li>";
			}
		if(!studyValidate()) {
			list=list + "<li>" + document.getElementById("Study").innerHTML + "</li>";
			}
		if(!centerValidate()) {
			list=list + "<li>" + document.getElementById("Center").innerHTML + "</li>";
			}
		if(!validateFormCheck()) {
			list=list + "<li>" + document.getElementById("Check").innerHTML + "</li>";
			}
		document.getElementById("error_message").innerHTML=list;
		return false;
		}
	}
				
	/* for First Name */
				
function fnameValidate() {
	var text=/^\s+$/;
	var x=document.myForm.fname.value;
	if(x=="" || text.test(x)){
		document.getElementById("first").innerHTML="The First Name field is required.";
		document.getElementById("first").className="property";
		document.myForm.fname.className="wrong";
		return false;
	}
	else{
		document.getElementById("first").innerHTML="";
		document.myForm.fname.className="correct";
		return true;
	}
}

	/* for Last Name */
	
function lnameValidate() {
	var text=/^\s+$/;
	var x=document.myForm.lname.value;
	if(x=="" || text.test(x)){
		document.getElementById("last").innerHTML="The Last Name field is required.";
		document.getElementById("last").className="property";
		document.myForm.lname.className="wrong";
		return false;
	}
	else{
		document.getElementById("last").innerHTML="";
		document.myForm.lname.className="correct";
		return true;
	}
	}

	/* for Gender */

function genderValidate() {
	if(document.myForm.gender.value==""){
		document.getElementById("gendero").innerHTML="The Gender field is required.";
		document.getElementById("gendero").className="property";
		document.getElementById("genderm").style.color="#a94442";
		document.getElementById("genderf").style.color="#a94442";
		
		return false;
		}
	else{
		document.getElementById("gendero").innerHTML="";
		document.getElementById("genderm").style.color="#007722";
		document.getElementById("genderf").style.color="#007722";
		return true;
		}
	}
			
function validateFormGender() {
	var male=document.getElementById("gender_male");
	var female=document.getElementById("gender_female");
	if(male.checked==true || female.checked==true){
		document.getElementById("gendero").innerHTML="";
		document.getElementById("genderm").style.color="#007722";
		document.getElementById("genderf").style.color="#007722";
		return true;
		}
	}
	
	/* for Email */
	
function emailValidate() {
	var text=/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
	var x=document.myForm.email.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Email").innerHTML="The Email field is required";
		document.getElementById("Email").className="property";
		document.myForm.email.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.email.className="correct";
		document.getElementById("Email").innerHTML="";
		return true;
		}
	}
	
function validateFormEmail() {
	var y=document.myForm.email.value;
	if(y.match(/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/)) {
		document.myForm.email.className="correct";
		document.getElementById("Email").innerHTML="";
		return true;
	}
	else {
		document.myForm.email.className="wrong";
		document.getElementById("Email").innerHTML="The Email field contains an invalid email address";
		document.getElementById("Email").className="property";
		return false;
	}
}

	/* for Phone number */
	
function phoneValidate() {
	var text=/^(7|8|9)\d{9}$/;
	var x=document.myForm.number.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Phone").innerHTML="The Phone Number/ Mobile Number field is required";
		document.getElementById("Phone").className="property";
		document.myForm.number.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.number.className="correct";
		document.getElementById("Phone").innerHTML="";
		return true;
		}
	}
	
function validateFormNumber() {
	var y=document.myForm.number.value;
	if(y.match(/^(7|8|9)\d{9}$/)) {
		document.myForm.number.className="correct";
		document.getElementById("Phone").innerHTML="";
		return true;
	}
	else {
		document.myForm.number.className="wrong";
		document.getElementById("Phone").innerHTML="The value of the Phone Number or Mobile Number is not valid";
		document.getElementById("Phone").className="property";
		return false;
	}
}

	/* for Country */
	
function countryValidate() {
	if(document.myForm.country.value==""){
		document.getElementById("Country").innerHTML="The Country of residence field is required.";
		document.getElementById("Country").className="property";
		document.myForm.country.className="valid_sel_wrong";
		
		return false;
		}
	else{
		document.getElementById("Country").innerHTML="";
		document.myForm.country.className="valid_sel_correct";
		return true;
		}
	}

	/* for Year of born */
	
function yearValidate() {
	var text=/\d{4}$/;
	var x=document.myForm.year.value;
	if(x=="" || !(text.test(x))) {
		document.getElementById("Year").innerHTML="The Year Born field is required";
		document.getElementById("Year").className="property";
		document.myForm.year.className="wrong";				
		return false;
		}
		
	else{
		document.myForm.year.className="correct";
		document.getElementById("Year").innerHTML="";
		return true;
		}
	}
	
function validateFormYear() {
	var y=document.myForm.year.value;
	if(y.match(/\d{4}$/) && y>=1900 && y<=2016) {
		document.myForm.year.className="correct";
		document.getElementById("Year").innerHTML="";
		return true;
	}
	else {
		document.myForm.year.className="wrong";
		document.getElementById("Year").innerHTML="The number in Year Born must be at least 1900 and no more than 2016";
		document.getElementById("Year").className="property";
		return false;
	}
}

	/* for Help */
	
function helpValidate() {
	if(document.myForm.help.value==""){
		document.getElementById("Help").innerHTML="The What do you need help with? field is required.";
		document.getElementById("Help").className="property";
		document.myForm.help.className="valid_sel_wrong";
		
		return false;
		}
	else{
		document.getElementById("Help").innerHTML="";
		document.myForm.help.className="valid_sel_correct";
		return true;
		}
	}

	/* for Study */

function studyValidate() {
	if(document.myForm.study.value==""){
		document.getElementById("Study").innerHTML="The Where would you like to study? field is required.";
		document.getElementById("Study").className="property";
		document.myForm.study.className="valid_sel_wrong";
		return false;
		}
	else {
		document.getElementById("Study").innerHTML="";
		document.myForm.study.className="valid_sel_correct";
		return true;
		}
	}

	/* for Center */
	
function centerValidate() {
	if(document.myForm.center.value==""){
		document.getElementById("Center").innerHTML="The What Center are you interested in field is required.";
		document.getElementById("Center").className="property";
		document.myForm.center.className="valid_sel_wrong";
		return false;
		}
	else {
		document.getElementById("Center").innerHTML="";
		document.myForm.center.className="valid_sel_correct";
		return true;
		}
	}

	/* for Checkbox */
	
function validateFormCheck() {
	var value=document.getElementById("check");
	if(value.checked==true){
		document.getElementById("Check").innerHTML="";
		return true;
		}
	else {
		document.getElementById("Check").innerHTML="The Terms And Conditions field is required.";
		document.getElementById("Check").className="property";
		return false;
		}
	}


