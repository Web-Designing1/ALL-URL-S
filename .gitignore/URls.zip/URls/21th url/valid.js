function submitFunction() {
	var fname=document.myForm.fname.value;
	var second=document.myForm.second.value;
	var third=document.myForm.third.value;
	var fourth=document.myForm.fourth.value;
	var fifth=document.myForm.fifth.value;
	var sixth=document.myForm.sixth.value;
	var seven=document.myForm.seven.value;
	var eight=document.myForm.eight.value;
	var nine=document.myForm.nine.value;
	var ten=document.myForm.ten.value;
	var leven=document.myForm.leven.value;
	if(fname && second && third && fourth && fifth && sixth && seven && eight && nine && ten && leven) {
		return true;
		}
	else {
		validateNonEmpty();
	 validateEmpty();
	 forradio();
	 forphone();
	 foremail();
	 foryear();
	 forselect();
	 formid();
	 forem();
	 foraus();
	 forsub();
		errorMessageDisplay();
		}
		return false;
			}	
			
function errorMessageDisplay() {
	var list="";
	if(fnameValidate() && lnameValidate() && genderValidate() && emailValidate() && phoneValidate() && countryValidate() && yearValidate() && helpValidate() && studyValidate() && centerValidate() && validateFormCheck()) {
		document.getElementById("error_message").innerHTML="";
		document.getElementById("error_message").className="error_message1";
		return true;
		}
	else {
		document.getElementById("error_message").className="error_message";
		if(!validateNonEmpty()) {
			list=list + "<li>" + document.getElementById("fin").innerHTML + "</li>";
			}
		if(!validateEmpty()) {
			list=list + "<li>" + document.getElementById("secd").innerHTML + "</li>";
			}
		if(!forradio()) {
			list=list + "<li>" + document.getElementById("thd").innerHTML + "</li>";
			}
		if(!foremail()) {
			list=list + "<li>" + document.getElementById("foth").innerHTML + "</li>";
			}
		if(!forphone()) {
			list=list + "<li>" + document.getElementById("5th").innerHTML + "</li>";
			}
		if(!forselect()) {
			list=list + "<li>" + document.getElementById("6th").innerHTML + "</li>";
			}
		if(!formid()) {
			list=list + "<li>" + document.getElementById("7th").innerHTML + "</li>";
			}
		if(!foryear()) {
			list=list + "<li>" + document.getElementById("8th").innerHTML + "</li>";
			}
		if(!foraus()) {
			list=list + "<li>" + document.getElementById("9th").innerHTML + "</li>";
			}
		if(!forem()) {
			list=list + "<li>" + document.getElementById("10th").innerHTML + "</li>";
			}
		if(!forsub()) {
			list=list + "<li>" + document.getElementById("11th").innerHTML + "</li>";
			}
		document.getElementById("error_message").innerHTML=list;
		return false;
		}
	}
		 function validateNonEmpty(){
	 var fname=document.myForm.fname;
	 if(fname.value=="")
	 {
		 document.getElementById("fin").innerHTML="O campo Nome é obrigatório.";
		 document.getElementById("fin").style.color="red";
		 fname.className="wrong";
		 return false;
	 }else
	 {
		 document.getElementById("fin").innerHTML="";
		 fname.className="tick";
		 return true;
	 }
		 
		}		
		function validateEmpty(){
	 var second=document.myForm.second;
	 if(second.value=="")
	 {
		 document.getElementById("secd").innerHTML="O campo Sobrenome é obrigatório.";
		  document.getElementById("secd").style.color="red";
		 second.className="wrong";
		 return false;
	 }else
	 {
		 document.getElementById("secd").innerHTML="";
		 second.className="tick";
		 return true;
	 }
		 
		}		
		function forradio(){
			var third=document.myForm.third;
			if(third.value=="")
			{
				document.getElementById("thd").innerHTML="O campo Sexo é obrigatório.";
				 document.getElementById("thd").style.color="red";
				third.className="wrong";
				return false;
			}
			else{
				document.getElementById("thd").innerHTML="";
				third.className="tick";
				return true;
			}
		}
		function foremail(){
			
    var fourth = document.getElementById('txtEmail');
			 var email = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			if(!email.test(fourth.value))
			{
				document.getElementById("foth").innerHTML="O campo E-mail é obrigatório.";
				 document.getElementById("foth").style.color="red";
				fourth.className="wrong";
				return false;
			}
			else{
				document.getElementById("foth").innerHTML="";
				fourth.className="tick";
				return true;
			}
		}
		function forphone(){
			var fifth=document.getElementById('txtphone');
			var phoneno=/^(7|8|9)\d{9}$/;
				if(!phoneno.test(fifth.value)){
				document.getElementById("5th").innerHTML="O campo Número do telefone/celular é obrigatório."
				 document.getElementById("5th").style.color="red";
				fifth.className="wrong";
				return false;
			}else {
				document.getElementById("5th").innerHTML="";
				fifth.className="tick";
				return true;
			}
		}
		function forselect(){
			var sixth=document.myForm.sixth;
			if(sixth.value=="")
			{
				document.getElementById("6th").innerHTML="O campo País de residência é obrigatório.";
				document.getElementById("6th").style.color="red";
				sixth.className="wrong";
				return false;
			}else
			{
				document.getElementById("6th").innerHTML="";
				sixth.className="tick";
				return true;
			}
		}
	function foryear(){
		var eight=document.myForm.eight;
		if(eight.value=="")
		{
			document.getElementById("8th").innerHTML="O campo Ano de nascimento é obrigatório.";
			document.getElementById("8th").style.color="red";
			eight.className="wrong";
			return false;
		}else{
			document.getElementById("8th").innerHTML="";
			eight.className="tick";
			return true;
		}
	}
	function formid(){
		var seven=document.myForm.seven;
		if(seven.value=="")
		{
			document.getElementById("7th").innerHTML="O campo No que podemos ajudar? é obrigatório.";
			document.getElementById("7th").style.color="red";
			seven.className="wrong";
			return false;
		}else{
			document.getElementById("7th").innerHTML="";
			seven.className="tick";
			return true;
		}
	}
function foraus(){
		var nine=document.myForm.nine;
		if(nine.value=="")
		{
			document.getElementById("9th").innerHTML="O campo País de interesse é obrigatório.";
			document.getElementById("9th").style.color="red";
			nine.className="wrong";
			return false;
		}else{
			document.getElementById("9th").innerHTML="";
			nine.className="tick";
			return true;
		}
	}

	function forsub(){
		var leven=document.myForm.leven;
		if(leven.value=="")
		{
			document.getElementById("11th").innerHTML="O campo Termos e condições é obrigatório.";
			document.getElementById("11th").style.color="red";
			leven.className="wrong";
			return false;
		}else{
			document.getElementById("11th").innerHTML="";
			leven.className="tick";
			return true;
		}
	}

 function forem(){
	 var ten=document.myForm.ten;
	 if(ten.value=="")
	 {
		 document.getElementById("10th").innerHtML="O campo Onde você deseja estudar? é obrigatório.";
		 document.getElementById("10th").style.color="red";
		 ten.className="wrong";
		 return false;
	 }
 
 else{
	 document.getElementById("10th").innerHTML="";
	 ten.className="tick";
	 return true;
 
	 }
 }		
